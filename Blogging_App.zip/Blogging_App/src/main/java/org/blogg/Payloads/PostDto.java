package org.blogg.Payloads;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PostDto {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Integer postId;
        @Column(nullable = false, length = 100)
        private String title;
        @Column(nullable = false, length = 10000)
        private String description;

        private UserDto user;
        private CategoryDto category;
}

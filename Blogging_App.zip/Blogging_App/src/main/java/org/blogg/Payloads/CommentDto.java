package org.blogg.Payloads;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CommentDto {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer commentId;
	@Column(nullable = false, length = 10000)
    private String text;
    
    private PostDto post;
}

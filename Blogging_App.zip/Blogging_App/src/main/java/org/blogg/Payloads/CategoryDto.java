package org.blogg.Payloads;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CategoryDto {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        Integer categoryId;
        String categoryName;

}

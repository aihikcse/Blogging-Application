package org.blogg.Model;
import lombok.*;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Post {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer postId;
	@Column(nullable = false, length = 100)
	private String title;
	@Column(nullable = false, length = 10000)
	private String description;

	@ManyToOne
	@JoinColumn(name = "UserId")
	private User user;
	
	@ManyToOne
	@JoinColumn(name = "categoryId")
	private Category category;

	@OneToMany(mappedBy = "post", cascade = CascadeType.ALL)
//	@JoinColumn(name = "pc_fid", referencedColumnName = "postId")
	List<Comment> comments = new ArrayList<>();
	}

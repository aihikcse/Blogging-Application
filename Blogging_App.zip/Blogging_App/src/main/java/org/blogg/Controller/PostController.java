package org.blogg.Controller;

import org.blogg.Payloads.PostDto;
import org.blogg.Service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/post")
public class PostController {
	@Autowired
	public PostService postService;
	
	public PostController(PostService postService) {
		super();
		this.postService = postService;
	}



	@PostMapping("/user/{userId}/category/{categoryId}/createPost")
	public ResponseEntity<PostDto> createPost(@RequestBody PostDto postDto,
											  @PathVariable Integer userId,
											  @PathVariable Integer categoryId){
		return new ResponseEntity<PostDto>(postService.createPost(postDto, userId, categoryId), HttpStatus.CREATED);
		
	}
//	@PutMapping("{postId}")
//	public ResponseEntity<Post> updatePost(@RequestBody Post post, @PathVariable("postId") Integer postId){
//		return new ResponseEntity<Post>(postService.updatePost(post, postId), HttpStatus.OK);
//	}
//	@DeleteMapping("{postId}")
//	public ResponseEntity<String> deletePost(@PathVariable("postId") Integer postId){
//		postService.deletePost(postId);
//		return new ResponseEntity<String>("The post with id: "+postId+" is deleted successfully.", HttpStatus.OK);
//	}
//	@GetMapping("{postId}")
//	public ResponseEntity<Post> findPost(@PathVariable("postId") Integer postId){
//		return new ResponseEntity<>(postService.findById(postId), HttpStatus.OK);
//	}
//	@GetMapping("/viewAllPost")
//	public List<Post> findAllPost(){
//		return postService.viewAllPost();
//	}

	@GetMapping("/user/{userId}/posts")
	public ResponseEntity<List<PostDto>> findPostByUser(@PathVariable Integer userId){
		return new ResponseEntity<>(postService.findPostByUser(userId), HttpStatus.OK);
	}

	@GetMapping("/category/{categoryId}/categories")
	public ResponseEntity<List<PostDto>> findPostByCategory(@PathVariable Integer categoryId){
		return new ResponseEntity<List<PostDto>>(postService.findPostByCategory(categoryId), HttpStatus.OK);
	}
}
